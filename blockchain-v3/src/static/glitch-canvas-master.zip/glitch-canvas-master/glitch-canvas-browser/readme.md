[![Build Status](https://travis-ci.org/snorpey/glitch-canvas.png?branch=master)](https://travis-ci.org/snorpey/glitch-canvas)
[![Greenkeeper badge](https://badges.greenkeeper.io/snorpey/glitch-canvas.svg)](https://greenkeeper.io/)

glitch-canvas-browser
=====================

```$ npm install glitch-canvas-browser```

what is it?
-----------
glitch-canvas is a javascript library for applying a glitch effect to a canvas element.

this is the dependency-free, browser-only version of the glitch-canvas package.

for more information and documentation, check out the [glitch-canvas package](https://www.npmjs.com/package/glitch-canvas) or the [glitch-canvas repository](https://github.com/snorpey/glitch-canvas/).