// import objectAssign from 'object-assign'
const objectAssign = Object.assign;
export default objectAssign;
