// import Canvas from 'canvas';
// import Canvas from './browser.js';
import Canvas from './node-canvas.js';
export default Canvas;
