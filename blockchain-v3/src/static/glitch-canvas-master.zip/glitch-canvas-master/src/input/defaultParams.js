export default {
	amount: 35,
	iterations: 20,
	quality: 30,
	seed: 25,
};
